
public class Checkpoint3 {

	public static void main(String[] args) throws IOException{
		
		//// TODO: Announce your GUI object to make the GUI ////
		//// TODO: For this work if you make every Character object to Random(), then you should plus the Round one and plus every Character.status one.
		//// Hint: How to put the image 
		//// Hint: first you should announce a ImageIcon e.g. ImageIcon image = new ImageIcon(Imagepath);
		//// Hint: then put it into layout object what you want to display on. e.g. JButton btn = new JButton(image);  or JLabel label = new JLabel(image);

	}
	
	public static void Load(String filename) throws IOException {
		//// TODO: You should load the variables from the file. ////

	}

	public static void Save(String filename) throws IOException {
		//// TODO: You should save the changed variables into original data (filename). ////
		
	}
	
	public static void Random() {
		//// TODO: while calling the Random function, Character.location should plus the random value, and Character.status should minus one.
		//// TODO: While Character.status more than zero(not include zero), Character can move(plus the random value).

	}

}