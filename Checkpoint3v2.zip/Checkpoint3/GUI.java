public class GUI extends JFame implements ActionListener{

    ////TODO: GUI ////


}