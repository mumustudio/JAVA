
public class Character {
	int location;
	int CHARACTER_NUMBER;
	int money;
	int status;
	String IMAGE_FILENAME;
	Character(int a, int b, int c, int d, String e){
		this.location = a;
		this.CHARACTER_NUMBER = b;
		this.money = c;
		this.status = d;
		this.IMAGE_FILENAME = e;
		
	}
}
